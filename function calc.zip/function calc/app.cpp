#include <iostream>
using namespace std;

void calc(double x, char y, double z) {
    switch(y) {
        case '+':
        cout << x + z << endl;
        break;
        case '-':
        cout << x - z << endl;
        break;
        case '*':
        cout << x * z << endl;
        break;
        case '/':
        if(z == 0) {
            cout << "can't divide by zero" << endl;
            break;
        } else {
            cout << x / z << endl;
            break;
        }
        default:
        cout << "invalid operation" << endl;
    }
}

int main() {
    double numA, numB;
    char oper;

    while(true) {
        cout << "enter an equation" << endl;
        cin >> numA;
        cin >> oper;
        cin >> numB;

        calc(numA,oper,numB);
    }
}